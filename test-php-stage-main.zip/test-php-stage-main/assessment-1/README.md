# Assessment 1

Show a list of the numbers from 1 to 100, where each number is a multiple of three and or five.

If a number is divisible by 3 show "Divisible by 3". If a number is divisible by 5 show "Divisible by 5". If a number is divisible by both, show both the texts.
