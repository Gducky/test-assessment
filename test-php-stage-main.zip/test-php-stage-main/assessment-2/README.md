# Assessment 2

In the `data` folder there is a text file available. Read the file and tell us how often the letter "e" exists in the document contents.
