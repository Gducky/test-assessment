# Assessment 4

In below example we have given an `ASCII` representation of a segment display. We would like to read it and use it somewhere else. We have multiple different sources and multiple different options. It is your task to convert it to an actual number.

>*Note: number should be converted as is, including leading zeroes.*

## Input

Below is the actual example display. The example code how to read it is already in the demo file.

```shell
 _     _  _     _  _  _  _  _ 
| |  | _| _||_||_ |_   ||_||_|
|_|  ||_  _|  | _||_|  ||_| _|
```
