<?php

declare(strict_types=1);

require_once('vendor/autoload.php');

chdir(dirname(__DIR__));

/**
 * Auto-generated code below to help you get started.
 */
$displays[] = file_get_contents('./data/display1.txt');
$displays[] = file_get_contents('./data/display2.txt');
$displays[] = file_get_contents('./data/display3.txt');
$displays[] = file_get_contents('./data/display4.txt');

var_dump($displays);