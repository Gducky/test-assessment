<?php
declare(strict_types=1);

namespace Senet;

class Display
{
    public function __construct()
    {
        // This is a dummy class to help the setup of autoloading
    }
}