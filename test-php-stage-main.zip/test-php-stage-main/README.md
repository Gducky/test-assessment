<p style="text-align: center;background-color:#fff;"><img src="https://www.senet.nl/wp-content/themes/senet/static/dist/images/senetlogo.svg"></p>

# PHP Test

Dear developer,

Welcome to the `Senet PHP Test`. In this test we will ask you to solve a number of use-cases.

Inside this projects there are a few folders, a new folder for each assessment. More explanation can be found inside each of these folders.

Some do's and dont's before we get started:

* We are developers, we are not robots so yes feel free to search the internet
* Commit your solution in GIT

Have fun and good luck!
