<?php
declare(strict_types=1);

namespace Senet;

use PHPUnit\Framework\TestCase;

class LeageTableTest extends TestCase
{
    public function testPlayerConstructor(): void
    {
        $instance = new LeagueTable([]);
        $this->assertCount(0, $instance->standings);

        $instanceWithPlayers = new LeagueTable(['foo', 'bar']);
        $this->assertCount(2, $instanceWithPlayers->standings);
    }

    public function testIfResultIsRecorded(): void
    {
        $playerName = 'me';
        $instance = new LeagueTable([$playerName]);
        $instance->recordResult($playerName, 8);
        $this->assertEquals(1, $instance->standings[$playerName]['games_played']);
        $this->assertEquals(8, $instance->standings[$playerName]['score']);

        $instance->recordResult($playerName, 2);
        $this->assertEquals(2, $instance->standings[$playerName]['games_played']);
        $this->assertEquals(10, $instance->standings[$playerName]['score']);
    }
}
