<?php
declare(strict_types=1);

namespace Senet;

class LeagueTable
{
    public array $standings = [];

    public function __construct(array $players)
    {
        foreach($players as $index => $p) {
            $this->standings[$p] = [
                'index'        => $index,
                'games_played' => 0,
                'score'        => 0
            ];
        }
    }

    public function recordResult(string $player, int $score) : void
    {
        $this->standings[$player]['games_played']++;
        $this->standings[$player]['score'] += $score;
    }

    public function getPlayerRank(int $rank) : string
    {
        return '';
    }
}