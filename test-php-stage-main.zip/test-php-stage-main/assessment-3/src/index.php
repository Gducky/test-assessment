<?php

declare(strict_types=1);

require_once('vendor/autoload.php');

use \Senet\LeagueTable;

chdir(dirname(__DIR__));

$table = new LeagueTable(array('Mike', 'Chris', 'Arnold'));
$table->recordResult('Mike', 2);
$table->recordResult('Mike', 3);
$table->recordResult('Arnold', 5);
$table->recordResult('Chris', 5);

var_dump($table->getPlayerRank(1));